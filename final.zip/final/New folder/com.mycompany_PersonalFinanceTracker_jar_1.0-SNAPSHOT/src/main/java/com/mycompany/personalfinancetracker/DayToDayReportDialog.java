package com.mycompany.personalfinancetracker;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.FileOutputStream;
import java.util.List;
import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import java.io.File;
import java.io.IOException;
import javax.swing.border.LineBorder;

public class DayToDayReportDialog extends JDialog {
    private final FinanceManager manager;

    public DayToDayReportDialog(JFrame parent, FinanceManager manager) {
        super(parent, "Day-to-Day Report", true);
        this.manager = manager;
        setUndecorated(true);
        initUI();
    }

    private void initUI() {
        setSize(800, 500);
        setLocationRelativeTo(getParent());
        setLayout(new BorderLayout());
        getRootPane().setBorder(new LineBorder(new Color(0, 200, 200), 3, true));

        JPanel titleBar = new JPanel(new BorderLayout());
titleBar.setBackground(Color.CYAN);
titleBar.setPreferredSize(new Dimension(getWidth(), 35));
JLabel titleLabel = new JLabel("Monthly Report Analysis", SwingConstants.CENTER);
titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
titleLabel.setForeground(Color.BLACK);
titleBar.add(titleLabel, BorderLayout.CENTER);

JButton closeBtn1 = new JButton("X");
JButton minimizeBtn = new JButton("—");
// style them with your styleButton method or a lighter variant
closeBtn1.addActionListener(e -> dispose());
//minimizeBtn.addActionListener(e -> setState(Frame.ICONIFIED));
minimizeBtn.addActionListener(e -> toBack());

JPanel btnPanel1 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 2));
btnPanel1.setOpaque(false);
btnPanel1.add(minimizeBtn);
btnPanel1.add(closeBtn1);

titleBar.add(btnPanel1, BorderLayout.EAST);
//add(titleBar, BorderLayout.NORTH);
        


        String my = manager.getCurrentMonthYear();
        if (my.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Set monthly income first!");
            dispose();
            return;
        }

        String fullMonth = manager.getFullMonthName(my);

        double income = manager.getMonthlyIncome(my);
        double totalExpenses = manager.getTotalExpenses(my);
        double totalLoans = manager.getTotalLoans(my);
        double finalSavings = manager.getFinalSavings(my);

        String summary = String.format("Summary for %s: Total Income ৳%.2f | Total Expenses ৳%.2f | Total Loans ৳%.2f | Final Savings ৳%.2f",
                fullMonth, income, totalExpenses, totalLoans, finalSavings);
        JTextArea sumArea = new JTextArea(summary);
        sumArea.setEditable(false);
        sumArea.setBackground(new Color(45, 45, 45));
        sumArea.setForeground(Color.WHITE);
        sumArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
       // add(sumArea, BorderLayout.NORTH);
// Container for title bar + summary
JPanel topContainer = new JPanel(new BorderLayout());
topContainer.add(titleBar, BorderLayout.NORTH);
topContainer.add(sumArea, BorderLayout.SOUTH);

// Add the container to the frame
add(topContainer, BorderLayout.NORTH);

        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Date", "Expense Sector", "Expense Amount", "Cumulative Savings", "Loan Amount"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        table.setRowHeight(25);
        table.getTableHeader().setBackground(new Color(45, 45, 45));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setBackground(new Color(45, 45, 45));
        table.setForeground(Color.WHITE);
        add(new JScrollPane(table), BorderLayout.CENTER);

        List<Transaction> txns = manager.getTransactionsCurrentMonth();
        double cumExp = 0, cumLoan = 0;
        for (Transaction t : txns) {
            cumExp += t.getExpenseAmount();
            cumLoan += t.getLoanAmount();
            double cumSav = income - cumExp - cumLoan;
            if (t.getLoanAmount() > 0) cumSav = 0.0;

            model.addRow(new Object[]{
                t.getDate(),
                t.getExpenseSector(),
                "৳ " + String.format("%.2f", t.getExpenseAmount()),
                "৳ " + String.format("%.2f", cumSav),
                "৳ " + String.format("%.2f", t.getLoanAmount())
            });
        }

        JButton exportBtn = new JButton("Export Detailed Date-Wise to PDF");
        exportBtn.addActionListener(e -> exportToPdf(fullMonth, income, totalExpenses, totalLoans, finalSavings, model));
        styleButton(exportBtn);

        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(e -> dispose());
        styleButton(closeBtn);

        JPanel btnPanel = new JPanel();
        btnPanel.setOpaque(false);
        btnPanel.add(exportBtn);
        btnPanel.add(closeBtn);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private void exportToPdf(String fullMonth, double income, double totalExp, double totalLoan, double finalSav, DefaultTableModel model) {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            String path = chooser.getSelectedFile().getAbsolutePath();
            if (!path.endsWith(".pdf")) path += ".pdf";

            try {
                Document document = new Document();
                PdfWriter.getInstance(document, new FileOutputStream(path));
                document.open();
com.lowagie.text.Font titleFont=new 
                        com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA,
                      18,com.lowagie.text.Font.BOLD);
Paragraph title =new Paragraph("Day-to-Day Detailed Report — "+fullMonth,titleFont);
                //document.add(new Paragraph("Day-to-Day Detailed Report — " + fullMonth));
                title.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(title);
                document.add(new  Paragraph("\n"));
                document.add(new Paragraph("Summary: Total Income ৳" + income + " | Total Expenses ৳" + totalExp + " | Total Loans ৳" + totalLoan + " | Final Savings ৳" + finalSav));
                document.add(new Paragraph(" "));

                PdfPTable table = new PdfPTable(5);
                table.addCell("Date");
                table.addCell("Expense Sector");
                table.addCell("Expense Amount");
                table.addCell("Cumulative Savings");
                table.addCell("Loan Amount");

                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < 5; j++) {
                        table.addCell(model.getValueAt(i, j).toString());
                    }
                }
                document.add(table);
                document.close();

                JOptionPane.showMessageDialog(this, "Detailed Date-Wise PDF exported successfully!");
              try {
                Desktop.getDesktop().open(new File(chooser.getSelectedFile() + ".pdf"));
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                    "Could not open PDF automatically: " + ex.getMessage(),
                    "Open Error", JOptionPane.ERROR_MESSAGE);
            }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Export Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void styleButton(JButton btn) {
        btn.setBackground(new Color(60, 63, 65));
        btn.setForeground(Color.WHITE);
       // btn.setBorder
       btn.setBorder(BorderFactory.createLineBorder(new Color(0,200,200), 2));
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    }
}