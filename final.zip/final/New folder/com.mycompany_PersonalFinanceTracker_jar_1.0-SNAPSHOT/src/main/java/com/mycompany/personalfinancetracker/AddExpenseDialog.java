package com.mycompany.personalfinancetracker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.function.Consumer;
import javax.swing.border.LineBorder;

public class AddExpenseDialog extends JDialog {
    private final FinanceManager manager;
    private final Consumer<Void> callback;
    private JTextField dateField;
    private JPanel calendarPanel;
    private boolean calendarVisible = false;

    public AddExpenseDialog(JFrame parent, FinanceManager manager, Consumer<Void> callback) {
        super(parent, "Add Expense / Loan", true);
        this.manager = manager;
        this.callback = callback;
        setUndecorated(true);

        initUI();
    }

    private void initUI() {
        setSize(450, 450);
        setLocationRelativeTo(getParent());
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(30, 30, 30));

        String my = manager.getCurrentMonthYear();
        if (my.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Set monthly income first!");
            dispose();
            return;
        }
        getRootPane().setBorder(new LineBorder(new Color(0, 200, 200), 3, true));

        JPanel titleBar = new JPanel(new BorderLayout());
        titleBar.setBackground(Color.CYAN);
        titleBar.setPreferredSize(new Dimension(getWidth(), 35));
        JLabel titleLabel = new JLabel("Add Expense / Loan", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setForeground(Color.BLACK);
        titleBar.add(titleLabel, BorderLayout.CENTER);

        JButton closeBtn = new JButton("X");
        JButton minimizeBtn = new JButton("–");
        closeBtn.addActionListener(e -> dispose());
        minimizeBtn.addActionListener(e -> toBack());

        MouseAdapter dragListener = new MouseAdapter() {
            Point offset;
            @Override
            public void mousePressed(MouseEvent e) {
                offset = e.getPoint();
            }
            @Override
            public void mouseDragged(MouseEvent e) {
                Point screen = e.getLocationOnScreen();
                setLocation(screen.x - offset.x, screen.y - offset.y);
            }
        };
        titleBar.addMouseListener(dragListener);
        titleBar.addMouseMotionListener(dragListener);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 2));
        btnPanel.setOpaque(false);
        btnPanel.add(minimizeBtn);
        btnPanel.add(closeBtn);

        titleBar.add(btnPanel, BorderLayout.EAST);
        add(titleBar, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setOpaque(false);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Date field with calendar button
        JPanel datePanel = new JPanel(new BorderLayout(5, 0));
        datePanel.setOpaque(false);
        dateField = makeField("dd/mm/yyyy or just digits", true);
        dateField.setToolTipText("Click calendar button or type: 12112025 → 12/11/2025");
        
        JButton calendarBtn = new JButton("📅");
        calendarBtn.setBorder(new LineBorder(new Color(0, 200, 200), 2, true));
        calendarBtn.setPreferredSize(new Dimension(45, 30));
        styleButton(calendarBtn);
        calendarBtn.addActionListener(e -> toggleCalendar());
        
        datePanel.add(dateField, BorderLayout.CENTER);
        datePanel.add(calendarBtn, BorderLayout.EAST);

        // Auto-format date as user types
        dateField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                autoFormatDate();
            }
        });

        JTextField sector = makeField("Expense Sector", true);
        sector.setToolTipText("Category for the expense, e.g., Food");
        JTextField spent = makeField("Spent Amount", true);
        spent.setToolTipText("Total amount spent");

        addRow(form, gbc, 0, "Date:", datePanel);
        addRow(form, gbc, 1, "Expense Sector:", sector);
        addRow(form, gbc, 2, "Spent Amount:", spent);

        // Calendar panel (initially hidden)
        calendarPanel = createCalendarPanel();
        calendarPanel.setVisible(false);

        JPanel formWithCalendar = new JPanel(new BorderLayout());
        formWithCalendar.setOpaque(false);
        formWithCalendar.add(form, BorderLayout.NORTH);
        formWithCalendar.add(calendarPanel, BorderLayout.CENTER);

        mainPanel.add(formWithCalendar, BorderLayout.CENTER);

        JButton save = new JButton("Save");
        save.setBorder(new LineBorder(new Color(0, 200, 200), 2, true));

        JButton cancel = new JButton("Cancel");
        cancel.setBorder(new LineBorder(new Color(0, 200, 200), 2, true));

        styleButton(save);
        styleButton(cancel);

        save.addActionListener(e -> saveTx(dateField, sector, spent, my));
        cancel.addActionListener(e -> dispose());

        JPanel btn = new JPanel();
        btn.setOpaque(false);
        btn.add(save);
        btn.add(cancel);
        
        add(mainPanel, BorderLayout.CENTER);
        add(btn, BorderLayout.SOUTH);
    }

    private JPanel createCalendarPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBackground(new Color(40, 40, 40));
        panel.setBorder(BorderFactory.createLineBorder(new Color(0,200,200), 2));

        LocalDate now = LocalDate.now();
        YearMonth yearMonth = YearMonth.of(now.getYear(), now.getMonth());

        // Header with month/year navigation
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        
        JButton prevBtn = new JButton("◀");
        prevBtn.setBorder(BorderFactory.createLineBorder(Color.cyan));
        JButton nextBtn = new JButton("▶");
        JLabel monthLabel = new JLabel(yearMonth.getMonth() + " " + yearMonth.getYear(), SwingConstants.CENTER);
        monthLabel.setForeground(Color.WHITE);
        monthLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        styleButton(prevBtn);
        styleButton(nextBtn);
        prevBtn.setPreferredSize(new Dimension(50, 30));
        nextBtn.setPreferredSize(new Dimension(50, 30));

        header.add(prevBtn, BorderLayout.WEST);
        header.add(monthLabel, BorderLayout.CENTER);
        header.add(nextBtn, BorderLayout.EAST);

        // Days grid
        JPanel daysPanel = new JPanel(new GridLayout(7, 7, 2, 2));
        daysPanel.setBackground(new Color(40, 40, 40));

        // Day headers
        String[] dayNames = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        for (String day : dayNames) {
            JLabel label = new JLabel(day, SwingConstants.CENTER);
            label.setForeground(new Color(150, 150, 150));
            label.setFont(new Font("Segoe UI", Font.BOLD, 11));
            daysPanel.add(label);
        }

        final YearMonth[] currentYearMonth = {yearMonth};
        
        Runnable updateCalendar = new Runnable() {
            @Override
            public void run() {
                // Remove old day buttons
                while (daysPanel.getComponentCount() > 7) {
                    daysPanel.remove(7);
                }

                monthLabel.setText(currentYearMonth[0].getMonth() + " " + currentYearMonth[0].getYear());

                LocalDate firstDay = currentYearMonth[0].atDay(1);
                int firstDayOfWeek = firstDay.getDayOfWeek().getValue() % 7;
                int daysInMonth = currentYearMonth[0].lengthOfMonth();

                // Empty cells before first day
                for (int i = 0; i < firstDayOfWeek; i++) {
                    daysPanel.add(new JLabel(""));
                }

                // Day buttons
                for (int day = 1; day <= daysInMonth; day++) {
                    JButton dayBtn = new JButton(String.valueOf(day));
                    dayBtn.setBorder(new LineBorder(new Color(0, 200, 200), 2, true));

                    styleButton(dayBtn);
                    dayBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                    
                    final int selectedDay = day;
                    dayBtn.addActionListener(e -> {
                        String date = String.format("%02d/%02d/%d", 
                            selectedDay, 
                            currentYearMonth[0].getMonthValue(), 
                            currentYearMonth[0].getYear());
                        dateField.setText(date);
                        calendarPanel.setVisible(false);
                        calendarVisible = false;
                        pack();
                    });
                    
                    // Highlight today
                    if (currentYearMonth[0].getYear() == now.getYear() && 
                        currentYearMonth[0].getMonth() == now.getMonth() && 
                        day == now.getDayOfMonth()) {
                        dayBtn.setBackground(new Color(70, 130, 180));
                    }
                    
                    daysPanel.add(dayBtn);
                }

                daysPanel.revalidate();
                daysPanel.repaint();
            }
        };

        prevBtn.addActionListener(e -> {
            currentYearMonth[0] = currentYearMonth[0].minusMonths(1);
            updateCalendar.run();
        });

        nextBtn.addActionListener(e -> {
            currentYearMonth[0] = currentYearMonth[0].plusMonths(1);
            updateCalendar.run();
        });

        updateCalendar.run();

        panel.add(header, BorderLayout.NORTH);
        panel.add(daysPanel, BorderLayout.CENTER);

        return panel;
    }

    private void toggleCalendar() {
        calendarVisible = !calendarVisible;
        calendarPanel.setVisible(calendarVisible);
        if (calendarVisible) {
            setSize(450, 600);
        } else {
            setSize(450, 450);
        }
        setLocationRelativeTo(getParent());
    }

    private void autoFormatDate() {
        String text = dateField.getText().replaceAll("[^0-9]", "");
        
        if (text.length() >= 8) {
            // Format: ddmmyyyy → dd/mm/yyyy
            String formatted = text.substring(0, 2) + "/" + 
                             text.substring(2, 4) + "/" + 
                             text.substring(4, 8);
            dateField.setText(formatted);
        }
    }

    private void saveTx(JTextField d, JTextField s, JTextField spentField, String my) {
        String date = d.getText().trim();
        String sec = s.getText().trim();
        String spentS = spentField.getText().trim();

        if (date.isEmpty() || sec.isEmpty() || spentS.isEmpty()) {
            err("All fields required");
            return;
        }

        try {
            double expenseAmount = Double.parseDouble(spentS);
            if (expenseAmount < 0) {
                err("Amount >= 0");
                return;
            }
            if (!date.matches("\\d{1,2}/\\d{1,2}/\\d{4}")) {
                err("Use dd/mm/yyyy format");
                return;
            }

            // Calculate current available balance (cumulative)
            double income = manager.getMonthlyIncome(my);
            double totalExpensesSoFar = manager.getTotalExpenses(my);
            double currentBalance = income - totalExpensesSoFar;
            
            // Expense is ALWAYS the full amount
            double expense = expenseAmount;
            double loan;
            
            if (currentBalance >= expenseAmount) {
                // We have enough balance - no loan needed
                loan = 0;
            } else if (currentBalance > 0) {
                // Partial balance - loan is the excess amount
                loan = expenseAmount - currentBalance;
            } else {
                // No balance (or negative) - entire expense becomes loan
                loan = expenseAmount;
            }

            manager.addTransaction(new Transaction(date, expense, loan, sec));
            
            // Show appropriate message
            String message;
            if (loan > 0) {
                message = String.format(
                    "Saved!\n\nExpense: ৳%.2f\nLoan: ৳%.2f\n\n⚠️ Insufficient savings - loan of ৳%.2f added.", 
                    expense, loan, loan
                );
            } else {
                message = String.format(
                    "Saved!\n\nExpense: ৳%.2f\nLoan: ৳%.2f\n\n✓ Deducted from savings.", 
                    expense, loan
                );
            }
            
            JOptionPane.showMessageDialog(this, message);
            callback.accept(null);
            dispose();
        } catch (Exception ex) {
            err("Invalid number");
        }
    }

    private void addRow(JPanel p, GridBagConstraints gbc, int y, String l, JComponent f) {
        gbc.gridx = 0;
        gbc.gridy = y;
        JLabel label = new JLabel(l);
        label.setForeground(Color.WHITE);
        p.add(label, gbc);
        gbc.gridx = 1;
        p.add(f, gbc);
    }

    private JTextField makeField(String ph, boolean ed) {
        JTextField tf = new JTextField(ph, 18);
        tf.setEditable(ed);
        tf.setBackground(new Color(40, 40, 40));
        tf.setForeground(Color.WHITE);
        tf.setCaretColor(Color.WHITE);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(100, 100, 100)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        return tf;
    }

    private void styleButton(JButton b) {
        b.setFocusPainted(false);
        b.setBackground(new Color(60, 63, 65));
        b.setForeground(Color.WHITE);
        b.setBorder(BorderFactory.createLineBorder(new Color(0,200,200)));
    }

    private void err(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}