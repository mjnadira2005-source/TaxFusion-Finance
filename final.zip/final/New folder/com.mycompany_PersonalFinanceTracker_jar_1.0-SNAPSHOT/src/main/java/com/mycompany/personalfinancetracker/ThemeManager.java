package com.mycompany.personalfinancetracker;

import java.awt.Color;

class ThemeManager {
    public enum ThemeType { DARK, LIGHT }
    private static ThemeType currentTheme = ThemeType.DARK;

    public static void setTheme(ThemeType theme) {
        currentTheme = theme;
    }

    public static ThemeType getTheme() {
        return currentTheme;
    }

    public static Color getBackground() {
        return currentTheme == ThemeType.DARK ? new Color(30, 30, 40) : Color.WHITE;
    }

    public static Color getForeground() {
        return currentTheme == ThemeType.DARK ? Color.WHITE : Color.BLACK;
    }

    public static Color getFieldBackground() {
        return currentTheme == ThemeType.DARK ? new Color(40, 45, 60) : new Color(240, 240, 240);
    }

    public static Color getTextColor() {
        return currentTheme == ThemeType.DARK ? Color.WHITE : Color.BLACK;
    }

    public static Color getAccent() {
        return currentTheme == ThemeType.DARK ? new Color(0, 220, 240) : new Color(0, 120, 180);
    }
}
