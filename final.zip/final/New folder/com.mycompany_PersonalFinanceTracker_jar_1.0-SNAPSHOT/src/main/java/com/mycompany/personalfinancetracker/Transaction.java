package com.mycompany.personalfinancetracker;

import java.io.Serializable;

public final class Transaction implements Serializable {
    private final String date;        // dd/MM/yyyy
    private final double expense;
    private final double loan;
    private final String sector;

    public Transaction(String date, double expense, double loan, String sector) {
        this.date = date;
        this.expense = expense;
        this.loan = loan;
        this.sector = sector;
    }

    public String getDate() { return date; }
    public double getExpenseAmount() { return expense; }
    public double getLoanAmount() { return loan; }
    public String getExpenseSector() { return sector; }

    public String getMonthYear() {
        return date.substring(3); // MM/yyyy
    }

    @Override
    public String toString() {
        return date + " | " + sector + " | Exp: ৳" + expense + " | Loan: ৳" + loan;
    }
}