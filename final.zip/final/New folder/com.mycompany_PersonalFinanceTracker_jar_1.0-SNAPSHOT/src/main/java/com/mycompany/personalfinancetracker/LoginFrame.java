package com.mycompany.personalfinancetracker;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.geom.*;
import java.util.HashMap;
import java.util.Map;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private static final Map<String, String> users = new HashMap<>();
    
    static {
        // Default users (In production, use database)
        users.put("admin", "admin123");
        users.put("user", "pass123");
    }

    public LoginFrame() {
        initUI();
    }
    
    private JPanel createTitleBar() {
    JPanel titleBar = new JPanel(new BorderLayout());
    titleBar.setBackground(new Color(0, 180, 220)); // Cyan-blue
    titleBar.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(0, 140, 170)));

    // Title text
    JLabel titleLabel = new JLabel(" 💵 TaxFusion Finance - Login");
    titleLabel.setForeground(Color.BLACK);
    titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
    titleBar.add(titleLabel, BorderLayout.WEST);

    // Control buttons (reuse your existing ones)
    JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 5));
    controlPanel.setOpaque(false);

    JButton minimizeBtn = createWindowButton("-",new Color(0,0,0));
    JButton maximizeBtn = createWindowButton("□", new Color(0, 0, 0));
    JButton closeBtn = createWindowButton("X", new Color(0, 0, 0));

    minimizeBtn.addActionListener(e -> setState(JFrame.ICONIFIED));
    maximizeBtn.addActionListener(e -> {
        if (getExtendedState() == JFrame.MAXIMIZED_BOTH) {
            setExtendedState(JFrame.NORMAL);
        } else {
            setExtendedState(JFrame.MAXIMIZED_BOTH);
        }
    });
    closeBtn.addActionListener(e -> System.exit(0));
    closeBtn.setForeground(new Color(0,0,0));

    controlPanel.add(minimizeBtn);
    controlPanel.add(maximizeBtn);
    controlPanel.add(closeBtn);

    titleBar.add(controlPanel, BorderLayout.EAST);

    return titleBar;
}


    private void initUI() {
        setTitle("TaxFusion Finance - Login");
        setSize(1000, 650);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
      //  setUndecorated(true);
       setUndecorated(true);

JPanel outerPanel = new JPanel(new BorderLayout());
outerPanel.setBorder(new LineBorder(new Color(0, 200, 220), 3));
outerPanel.setBackground(new Color(0, 200, 220));

outerPanel.add(createTitleBar(), BorderLayout.NORTH);

JPanel mainPanel = new JPanel(new GridLayout(1, 2));
mainPanel.add(createGraphicsPanel());
mainPanel.add(createLoginPanel());

outerPanel.add(mainPanel, BorderLayout.CENTER);
add(outerPanel, BorderLayout.CENTER);

addDraggableWindow();


    
        // Add window dragging
        addDraggableWindow();
    }

    private JPanel createGraphicsPanel() {
        JPanel panel = new FinanceGraphicsPanel();
        panel.setBackground(new Color(0, 180, 200));
        return panel;
    }

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Gradient background
                GradientPaint gradient = new GradientPaint(
                    0, 0, new Color(20, 20, 30),
                    0, getHeight(), new Color(30, 30, 45)
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                
                // Decorative circles
                g2d.setColor(new Color(0, 200, 220, 30));
                g2d.fillOval(-50, -50, 200, 200);
                g2d.fillOval(getWidth() - 150, getHeight() - 150, 200, 200);
            }
        };
        
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Window control buttons (top right)
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 5));
        controlPanel.setOpaque(false);
        
        JButton minimizeBtn = createWindowButton("-", new Color(0, 0, 0));
        JButton maximizeBtn = createWindowButton("□", new Color(0, 0, 0));
        JButton closeBtn = createWindowButton("X", new Color(0, 0, 0));
        
        minimizeBtn.addActionListener(e -> setState(JFrame.ICONIFIED));
        maximizeBtn.addActionListener(e -> {
            if (getExtendedState() == JFrame.MAXIMIZED_BOTH) {
                setExtendedState(JFrame.NORMAL);
            } else {
                setExtendedState(JFrame.MAXIMIZED_BOTH);
            }
        });
        closeBtn.addActionListener(e -> System.exit(0));
        closeBtn.setForeground(new Color(0,0,0));
        
        controlPanel.add(minimizeBtn);
        controlPanel.add(maximizeBtn);
        controlPanel.add(closeBtn);
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        panel.add(controlPanel, gbc);

        // Decorative icon at top
        JLabel iconLabel = new JLabel("$");
        iconLabel.setFont(new Font("Segoe UI", Font.BOLD, 60));
        iconLabel.setForeground(new Color(0, 220, 240));
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 20, 10, 20);
        panel.add(iconLabel, gbc);

        // Logo/Title with cute font
        JLabel titleLabel = new JLabel("TaxFusion Finance");
        titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 36));
        titleLabel.setForeground(new Color(0, 220, 240));
        gbc.gridy = 2;
        gbc.insets = new Insets(5, 20, 5, 20);
        panel.add(titleLabel, gbc);

        JLabel subtitleLabel = new JLabel("*** Secure Login Portal ***");
        subtitleLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        subtitleLabel.setForeground(new Color(150, 200, 220));
        gbc.gridy = 3;
        gbc.insets = new Insets(5, 20, 25, 20);
        panel.add(subtitleLabel, gbc);

        // Username field
        gbc.gridwidth = 1;
        gbc.gridy = 4;
        gbc.insets = new Insets(10, 20, 5, 20);
        JLabel userLabel = new JLabel(">> Username");
        userLabel.setForeground(new Color(180, 220, 240));
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        panel.add(userLabel, gbc);

        gbc.gridy = 5;
        gbc.gridwidth = 2;
        usernameField = createStyledTextField();
        usernameField.setPreferredSize(new Dimension(320, 45));
        panel.add(usernameField, gbc);

      // Password label
gbc.gridy = 6;
gbc.gridx = 0;
gbc.gridwidth = 1;
gbc.insets = new Insets(20, 20, 5, 20);
JLabel passLabel = new JLabel(">> Password");
passLabel.setForeground(new Color(180, 220, 240));
passLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
panel.add(passLabel, gbc);

// Password field
gbc.gridy = 7;
gbc.gridx = 0;
gbc.gridwidth = 1;
passwordField = createStyledPasswordField();
passwordField.setPreferredSize(new Dimension(240, 45));
panel.add(passwordField, gbc);

// Show/Hide password toggle
gbc.gridx = 1;
gbc.anchor = GridBagConstraints.WEST;
JCheckBox showPasswordCheck = new JCheckBox("Show");
showPasswordCheck.setOpaque(false);
showPasswordCheck.setForeground(new Color(180, 220, 240));
showPasswordCheck.setFont(new Font("Segoe UI", Font.PLAIN, 12));
showPasswordCheck.addActionListener(e -> {
    if (showPasswordCheck.isSelected()) {
        passwordField.setEchoChar((char) 0); // show plain text
    } else {
        passwordField.setEchoChar('*');      // mask with stars
    }
});
panel.add(showPasswordCheck, gbc);




        // Login button with icon
        gbc.gridy = 8;
        gbc.insets = new Insets(30, 20, 8, 20);
        JButton loginBtn = createStyledButton(">>> LOGIN <<<", new Color(0, 200, 220));
        loginBtn.addActionListener(e -> handleLogin());
        panel.add(loginBtn, gbc);

        // Register button with icon
        gbc.gridy = 9;
        gbc.insets = new Insets(8, 20, 8, 20);
        JButton registerBtn = createStyledButton("+ CREATE ACCOUNT +", new Color(100, 100, 220));
        registerBtn.addActionListener(e -> handleRegister());
        panel.add(registerBtn, gbc);

        // Divider with symbols
        gbc.gridy = 10;
        gbc.insets = new Insets(15, 20, 5, 20);
        JLabel divider = new JLabel("========== $ ==========");
        divider.setForeground(new Color(100, 100, 120));
        divider.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        panel.add(divider, gbc);

        // Info label
        gbc.gridy = 11;
        gbc.insets = new Insets(5, 20, 20, 20);
        JLabel infoLabel = new JLabel("<html><center>*** Demo Credentials ***<br>admin / admin123<br>user / pass123</center></html>");
        infoLabel.setForeground(new Color(120, 140, 160));
        infoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        panel.add(infoLabel, gbc);
        
        // Theme toggle
gbc.gridy = 12;
gbc.insets = new Insets(10, 20, 20, 20);
JCheckBox themeToggle = new JCheckBox("Light Theme");
themeToggle.setOpaque(false);
themeToggle.setForeground(Color.YELLOW);
themeToggle.setFont(new Font("Segoe UI", Font.PLAIN, 12));

//themeToggle.addActionListener(e -> {
//    if (themeToggle.isSelected()) {
//        ThemeManager.setTheme(ThemeManager.ThemeType.LIGHT);
//    } else {
//        ThemeManager.setTheme(ThemeManager.ThemeType.DARK);
//    }

    // Refresh ALL open frames in the app
//    for (Frame frame : Frame.getFrames()) {
//        SwingUtilities.updateComponentTreeUI(frame);
//        frame.repaint();
//    }
//});
//
//panel.add(themeToggle, gbc);


        return panel;
    }

    private JButton createWindowButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        //btn.setBorderPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(4,10,4,10));
        btn.setContentAreaFilled(false);
        btn.setForeground(new Color(0,0,0));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(40, 30));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (text.equals("X")) {
                    btn.setForeground(new Color(255, 100, 100));
                } else {
                    btn.setForeground(new Color(100, 240, 255));
                }
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                if (text.equals("X")) {
                    btn.setForeground(new Color(255, 100, 100));
                } else {
                    btn.setForeground(new Color(180, 220, 240));
                }
            }
        });
        
        return btn;
    }

    private JTextField createStyledTextField() {
        JTextField field = new JTextField();
        field.setBackground(new Color(40, 45, 60));
        field.setForeground(Color.WHITE);
        field.setCaretColor(new Color(0, 220, 240));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(0, 200, 220), 3, true),
            BorderFactory.createEmptyBorder(10, 18, 10, 18)
        ));
        return field;
    }

    private JPasswordField createStyledPasswordField() {
        JPasswordField field = new JPasswordField();
        field.setBackground(new Color(40, 45, 60));
        field.setForeground(Color.WHITE);
        field.setCaretColor(new Color(0, 220, 240));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(0, 200, 220), 3, true),
            BorderFactory.createEmptyBorder(10, 18, 10, 18)
        ));
        field.setEchoChar('*');
        return field;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setPreferredSize(new Dimension(320, 50));
        btn.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(0, 220, 240), 3, true),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(bgColor.brighter());
                btn.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(100, 240, 255), 3, true),
                    BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(bgColor);
                btn.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(0, 220, 240), 3, true),
                    BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
        });
        
        return btn;
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            showError("[!] Please enter username and password");
            return;
        }

        if (users.containsKey(username) && users.get(username).equals(password)) {
            // Success with custom dialog
            showSuccessDialog("Login Successful!\n\nWelcome back, " + username + "!");
            
            // Open main application
            SwingUtilities.invokeLater(() -> {
                new MainFrame(new FinanceManager()).setVisible(true);
                dispose();
            });
        } else {
            showError("[X] Invalid username or password");
            passwordField.setText("");
        }
    }

    private void handleRegister() {
      
    JPanel panel = new JPanel(new GridLayout(6, 2, 10, 15));
    panel.setBackground(new Color(30, 30, 40));
    panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

    JLabel userLabel = new JLabel(">> Username:");
    userLabel.setForeground(Color.WHITE);
    userLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
    JTextField newUser = createStyledTextField();

    JLabel passLabel = new JLabel(">> Password:");
    passLabel.setForeground(Color.WHITE);
    passLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
    JPasswordField newPass = createStyledPasswordField();

    // Show/Hide password toggle
    JCheckBox showPassCheck = new JCheckBox("Show");
    showPassCheck.setOpaque(false);
    showPassCheck.setForeground(new Color(180, 220, 240));
    showPassCheck.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    showPassCheck.addActionListener(e -> {
        if (showPassCheck.isSelected()) {
            newPass.setEchoChar((char) 0);
        } else {
            newPass.setEchoChar('*');
        }
    });

    JLabel confirmLabel = new JLabel(">> Confirm Password:");
    confirmLabel.setForeground(Color.WHITE);
    confirmLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
    JPasswordField confirmPass = createStyledPasswordField();

    // Show/Hide confirm password toggle
    JCheckBox showConfirmCheck = new JCheckBox("Show");
    showConfirmCheck.setOpaque(false);
    showConfirmCheck.setForeground(new Color(180, 220, 240));
    showConfirmCheck.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    showConfirmCheck.addActionListener(e -> {
        if (showConfirmCheck.isSelected()) {
            confirmPass.setEchoChar((char) 0);
        } else {
            confirmPass.setEchoChar('*');
        }
    });

    JLabel noteLabel = new JLabel("*** Tip: Use a strong password! ***");
    noteLabel.setForeground(new Color(100, 200, 220));
    noteLabel.setFont(new Font("Segoe UI", Font.ITALIC, 11));

    // Add components to panel
    panel.add(userLabel); panel.add(newUser);
    panel.add(passLabel); panel.add(newPass);
    panel.add(new JLabel("")); panel.add(showPassCheck); // toggle next to password
    panel.add(confirmLabel); panel.add(confirmPass);
    panel.add(new JLabel("")); panel.add(showConfirmCheck); // toggle next to confirm
    panel.add(noteLabel); panel.add(new JLabel("")); // filler

    // Title bar
    JLabel titleBarLabel = new JLabel("   *** Create New Account ***   ");
    titleBarLabel.setOpaque(true);
    titleBarLabel.setBackground(new Color(0, 180, 220));
    titleBarLabel.setForeground(Color.WHITE);
    titleBarLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
    titleBarLabel.setHorizontalAlignment(SwingConstants.CENTER);
    titleBarLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JPanel dialogPanel = new JPanel(new BorderLayout(0, 0));
    dialogPanel.setBackground(new Color(30, 30, 40));
    dialogPanel.add(titleBarLabel, BorderLayout.NORTH);
    dialogPanel.add(panel, BorderLayout.CENTER);

    int result = JOptionPane.showConfirmDialog(this, dialogPanel,
            "", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
        String username = newUser.getText().trim();
        String password = new String(newPass.getPassword());
        String confirm = new String(confirmPass.getPassword());

        // validation logic (same as before)...
    


            
            if (username.isEmpty() || password.isEmpty()) {
                showError("[!] Username and password cannot be empty");
                return;
            }
            
            if (password.length() < 6) {
                showError("[!] Password must be at least 6 characters");
                return;
            }
            
            if (!password.equals(confirm)) {
                showError("[X] Passwords do not match");
                return;
            }
            
            if (users.containsKey(username)) {
                showError("[!] Username already exists");
                return;
            }
            
            users.put(username, password);
            showSuccessDialog("Account created successfully!\n\nTime to shine ! Let's go , " + username + "!\n\nYou can now login with your credentials.");
        }
    }

    private void showSuccessDialog(String message) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(new Color(30, 30, 40));
        panel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(0, 220, 100), 3, true),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        // Title bar with RGB(154, 209, 212)
        JLabel titleBar = new JLabel("   Success    ");
        titleBar.setOpaque(true);
        titleBar.setBackground(new Color(0, 180, 220));
        titleBar.setForeground(Color.WHITE);
        titleBar.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleBar.setHorizontalAlignment(SwingConstants.CENTER);
        titleBar.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        // Message
        JLabel messageLabel = new JLabel("<html><center>" + message.replace("\n", "<br>") + "</center></html>");
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        messageLabel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10));

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.add(titleBar, BorderLayout.NORTH);
        contentPanel.add(messageLabel, BorderLayout.CENTER);

        panel.add(contentPanel, BorderLayout.CENTER);

        JOptionPane.showMessageDialog(this, panel, "", JOptionPane.PLAIN_MESSAGE);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void addDraggableWindow() {
        final Point[] mouseDownCompCoords = new Point[1];
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent e) {
                mouseDownCompCoords[0] = e.getPoint();
            }
        });
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent e) {
                Point currCoords = e.getLocationOnScreen();
                setLocation(currCoords.x - mouseDownCompCoords[0].x, 
                           currCoords.y - mouseDownCompCoords[0].y);
            }
        });
    }

    // Custom panel with finance graphics
    class FinanceGraphicsPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Gradient background
            GradientPaint gradient = new GradientPaint(
                0, 0, new Color(0, 180, 200),
                0, getHeight(), new Color(0, 140, 170)
            );
            g2d.setPaint(gradient);
            g2d.fillRect(0, 0, getWidth(), getHeight());

            // Decorative patterns
            drawFloatingIcons(g2d);
            drawCoins(g2d);
            drawChart(g2d);
            drawMoneySymbols(g2d);
            
            // Title section
            g2d.setColor(new Color(255, 255, 255, 230));
            g2d.setFont(new Font("Comic Sans MS", Font.BOLD, 42));
            String title = "Welcome Back!";
            FontMetrics fm = g2d.getFontMetrics();
            int x = (getWidth() - fm.stringWidth(title)) / 2;
            g2d.drawString(title, x, 90);
            
            g2d.setFont(new Font("Comic Sans MS", Font.PLAIN, 18));
            g2d.setColor(new Color(255, 255, 255, 200));
            String subtitle = "*** Your Smart Finance Companion ***";
            fm = g2d.getFontMetrics();
            x = (getWidth() - fm.stringWidth(subtitle)) / 2;
            g2d.drawString(subtitle, x, 125);
            
            // Feature badges
            drawFeatureBadges(g2d);
        }

        private void drawFloatingIcons(Graphics2D g2d) {
            // Using text symbols instead of emojis
            String[] icons = {"$", "$", "$", "€", "¥", "£", "$", "¢"};
            int[] xPos = {30, 380, 60, 350, 420, 90, 400, 180};
            int[] yPos = {480, 520, 200, 180, 350, 550, 450, 530};
            int[] sizes = {30, 35, 28, 28, 28, 30, 28, 24};
            
            for (int i = 0; i < icons.length; i++) {
                g2d.setFont(new Font("Segoe UI", Font.BOLD, sizes[i]));
                g2d.setColor(new Color(255, 255, 255, 120 + (i * 10) % 80));
                g2d.drawString(icons[i], xPos[i], yPos[i]);
            }
        }

        private void drawCoins(Graphics2D g2d) {
            // Large decorative coin
            GradientPaint coinGradient = new GradientPaint(
                50, 150, new Color(255, 215, 0, 150),
                130, 230, new Color(255, 195, 0, 100)
            );
            g2d.setPaint(coinGradient);
            g2d.fillOval(50, 150, 90, 90);
            
            g2d.setColor(new Color(255, 235, 0, 180));
            g2d.setStroke(new BasicStroke(3));
            g2d.drawOval(50, 150, 90, 90);
            
            g2d.setColor(new Color(255, 255, 255, 200));
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 40));
            g2d.drawString("$", 78, 208);
            
            // Medium coin
            coinGradient = new GradientPaint(
                340, 380, new Color(255, 215, 0, 130),
                400, 440, new Color(255, 195, 0, 80)
            );
            g2d.setPaint(coinGradient);
            g2d.fillOval(340, 380, 70, 70);
            
            g2d.setColor(new Color(255, 235, 0, 160));
            g2d.setStroke(new BasicStroke(2));
            g2d.drawOval(340, 380, 70, 70);
            
            g2d.setColor(new Color(255, 255, 255, 180));
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 30));
            g2d.drawString("€", 360, 425);
        }

        private void drawChart(Graphics2D g2d) {
            g2d.setColor(new Color(255, 255, 255, 140));
            g2d.setStroke(new BasicStroke(3));
            
            // Axes
            g2d.drawLine(70, 380, 70, 280);
            g2d.drawLine(70, 380, 230, 380);
            
            // Bars with gradient
            int[] barHeights = {55, 85, 40, 95, 65};
            int barWidth = 24;
            int spacing = 12;
            
            for (int i = 0; i < barHeights.length; i++) {
                int xPos = 85 + i * (barWidth + spacing);
                int yPos = 380 - barHeights[i];
                
                GradientPaint barGradient = new GradientPaint(
                    xPos, yPos, new Color(255, 255, 255, 200),
                    xPos, 380, new Color(255, 255, 255, 120)
                );
                g2d.setPaint(barGradient);
                g2d.fillRoundRect(xPos, yPos, barWidth, barHeights[i], 8, 8);
                
                // Star on top of bars
                g2d.setColor(new Color(255, 255, 100, 200));
                g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));
                g2d.drawString("*", xPos + 8, yPos - 5);
            }
        }

        private void drawMoneySymbols(Graphics2D g2d) {
            g2d.setFont(new Font("Arial", Font.BOLD, 50));
            g2d.setColor(new Color(255, 255, 255, 70));
            g2d.drawString("$", 310, 270);
            g2d.drawString("€", 140, 520);
            g2d.drawString("£", 380, 150);
            g2d.drawString("¥", 420, 280);
        }
        
        private void drawFeatureBadges(Graphics2D g2d) {
            String[] features = {">> Secure", ">> Easy", ">> Fast", ">> Free"};

            // Background colors (unchanged)
            Color[] bgColors = {
                new Color(131, 197, 190),   // Secure → Ocean Perl Delight
                new Color(159, 160, 195),   // Easy → Summer Hues
                new Color(230,230,250),     // Fast → Lavender
                new Color(216, 191, 216)    // Free → D8BFD8
            };

            // Border colors (unchanged)
            Color[] borderColors = {
                new Color(205, 4, 121),     // Secure → Cameroon rose 
                new Color(26, 39, 150),     // Easy → Cherry on Top 1A2796
                new Color(148, 0, 211),     // Fast → Dark Violet
                new Color(128,0,0)          // Free → Maroon
            };

            int startY = 440;
            int spacing = 35;

            g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));

            for (int i = 0; i < features.length; i++) {
                // Background gradient
                GradientPaint badgeGradient = new GradientPaint(
                    155, startY + (i * spacing),
                    bgColors[i],
                    345, startY + (i * spacing),
                    bgColors[i].brighter()
                );

                g2d.setPaint(badgeGradient);
                g2d.fillRoundRect(155, startY + (i * spacing), 190, 28, 15, 15);

                // Border
                g2d.setColor(borderColors[i]);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawRoundRect(155, startY + (i * spacing), 190, 28, 15, 15);

                // Text
                g2d.setColor(new Color(0, 60, 80));
                g2d.drawString(features[i], 175, startY + (i * spacing) + 19);
            }
        }
    }

    public static void main(String[] args) {
        // Set dark theme for dialogs
        try {
            UIManager.put("OptionPane.background", new Color(30, 30, 40));
            UIManager.put("Panel.background", new Color(30, 30, 40));
            UIManager.put("OptionPane.messageForeground", Color.WHITE);
            UIManager.put("Button.background", new Color(60, 63, 75));
            UIManager.put("Button.foreground", Color.WHITE);
            UIManager.put("TextField.background", new Color(40, 45, 60));
            UIManager.put("TextField.foreground", Color.WHITE);
            UIManager.put("Label.foreground", Color.WHITE);
//UIManager.put("OptionPane.background", ThemeManager.getBackground());
//UIManager.put("Panel.background", ThemeManager.getBackground());
//UIManager.put("OptionPane.messageForeground", ThemeManager.getForeground());
//UIManager.put("Button.background", ThemeManager.getAccent());
//UIManager.put("Button.foreground", ThemeManager.getForeground());
//UIManager.put("TextField.background", ThemeManager.getBackground());
//UIManager.put("TextField.foreground", ThemeManager.getForeground());
//UIManager.put("Label.foreground", ThemeManager.getForeground());

        } catch (Exception e) {
            e.printStackTrace();
        }
      

        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}