package com.mycompany.personalfinancetracker;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileOutputStream;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import javax.swing.table.DefaultTableModel;

public class TaxDialog extends JDialog {

    private final FinanceManager manager;
    private JTextField incomeField;
    private JRadioButton maleButton, femaleButton;
    private JCheckBox shanchayCheckBox;
    private JTextArea resultArea;
    DefaultTableModel tableModel;
    JTable resultTable;
    private Point initialClick;
    private JTextField savingsAmountField;
    
    double savingsAmount;

    public TaxDialog(JFrame parent, FinanceManager manager) {
        super(parent, true);
        this.manager = manager;
        setUndecorated(true);
        initUI();
        setSize(800, 550);
        setLocationRelativeTo(parent);
    }

    private void initUI() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(25, 25, 25));

        // ---------- Title Bar ----------
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(0, 200, 255));
        header.setPreferredSize(new Dimension(600, 40));
        header.setBorder(BorderFactory.createLineBorder(new Color(0, 200, 255), 2));

        JLabel title = new JLabel("💰 Tax Calculator");
        title.setForeground(Color.BLACK);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));

        // Close button
        JButton closeBtn = new JButton("X");
        closeBtn.setFocusPainted(false);
        closeBtn.setBorderPainted(false);
        closeBtn.setBackground(new Color(0, 200, 255));
        closeBtn.setForeground(Color.BLACK);
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeBtn.addActionListener(e -> dispose());

        // Minimize button
        JButton minimizeBtn = new JButton("–");
        minimizeBtn.setFocusPainted(false);
        minimizeBtn.setBorderPainted(false);
        minimizeBtn.setBackground(new Color(0, 200, 255));
        minimizeBtn.setForeground(Color.BLACK);
        minimizeBtn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        minimizeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        minimizeBtn.addActionListener(e -> this.setVisible(true));

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        buttonsPanel.setOpaque(false);
        buttonsPanel.add(minimizeBtn);
        buttonsPanel.add(closeBtn);

        header.add(title, BorderLayout.WEST);
        header.add(buttonsPanel, BorderLayout.EAST);

        // Make header draggable
        header.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent e) {
                initialClick = e.getPoint();
            }
        });
        header.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent e) {
                int thisX = getLocation().x;
                int thisY = getLocation().y;
                int xMoved = e.getX() - initialClick.x;
                int yMoved = e.getY() - initialClick.y;
                setLocation(thisX + xMoved, thisY + yMoved);
            }
        });

        add(header, BorderLayout.NORTH);

        // ---------- Input Panel ----------
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
        inputPanel.setBackground(new Color(25, 25, 25));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        inputPanel.setPreferredSize(new Dimension(320, 0));

        // Monthly Income
        JLabel incomeLabel = new JLabel("Monthly Income (৳):");
        incomeLabel.setForeground(Color.WHITE);
        incomeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        incomeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        incomeField = new JTextField(String.format("%.2f", manager.getMonthlyIncome(manager.getCurrentMonth())));
        styleField(incomeField);
        incomeField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));

        inputPanel.add(incomeLabel);
        inputPanel.add(Box.createVerticalStrut(4));
        inputPanel.add(incomeField);
        inputPanel.add(Box.createVerticalStrut(12));

        // Gender
        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setForeground(Color.WHITE);
        genderLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        maleButton = new JRadioButton("Male");
        femaleButton = new JRadioButton("Female");
        styleRadio(maleButton);
        styleRadio(femaleButton);

        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleButton);
        genderGroup.add(femaleButton);
        maleButton.setSelected(true);

        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        genderPanel.setBackground(new Color(25, 25, 25));
        genderPanel.add(genderLabel);
        genderPanel.add(maleButton);
        genderPanel.add(femaleButton);
        inputPanel.add(genderPanel);

        inputPanel.add(Box.createVerticalStrut(10));
        JSeparator separator = new JSeparator();
        separator.setForeground(new Color(0, 200, 200));
        separator.setMaximumSize(new Dimension(320, 1));
        inputPanel.add(separator);
        inputPanel.add(Box.createVerticalStrut(10));

        // Savings Certificate Section
        JPanel savingsCertPanel = new JPanel();
        savingsCertPanel.setLayout(new BoxLayout(savingsCertPanel, BoxLayout.Y_AXIS));
        savingsCertPanel.setBackground(new Color(25, 25, 25));
        savingsCertPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Flag + Checkbox in one row
        JPanel flagCheckPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        flagCheckPanel.setBackground(new Color(25, 25, 25));
        flagCheckPanel.setMaximumSize(new Dimension(280, 50)); // Increased height for wrapping

        BangladeshFlag flagIcon = new BangladeshFlag();
        flagIcon.setPreferredSize(new Dimension(28, 20));
        flagCheckPanel.add(flagIcon);

        // Use HTML to wrap text properly
        shanchayCheckBox = new JCheckBox("<html>✅ Has Savings Certificate<br>(10% rebate)</html>");
        shanchayCheckBox.setForeground(Color.WHITE);
        shanchayCheckBox.setBackground(new Color(25, 25, 25));
        shanchayCheckBox.setFocusPainted(false);
        shanchayCheckBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        shanchayCheckBox.setPreferredSize(new Dimension(220, 40)); // Fixed size to show full text
        flagCheckPanel.add(shanchayCheckBox);

        savingsCertPanel.add(flagCheckPanel);
        savingsCertPanel.add(Box.createVerticalStrut(8));

        // Amount label
        JLabel amountLabel = new JLabel("Investment Amount (৳):");
        amountLabel.setForeground(Color.WHITE);
        amountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        amountLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        savingsCertPanel.add(amountLabel);
        savingsCertPanel.add(Box.createVerticalStrut(4));

        // Savings amount field
        savingsAmountField = new JTextField();
        styleField(savingsAmountField);
        savingsAmountField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        savingsAmountField.setEnabled(false);
        savingsCertPanel.add(savingsAmountField);

        // Checkbox listener
        shanchayCheckBox.addActionListener(e -> savingsAmountField.setEnabled(shanchayCheckBox.isSelected()));

        inputPanel.add(savingsCertPanel);
        add(inputPanel, BorderLayout.WEST);

        // ---------- Result Table ----------
        String[] columnNames = {"Description", "Amount (৳)"};
        tableModel = new DefaultTableModel(columnNames, 0);
        tableModel.addRow(new Object[]{"Annual Income", 0.0});
        tableModel.addRow(new Object[]{"Taxable Income", 0.0});
        tableModel.addRow(new Object[]{"Tax Rate", "10%"});
        tableModel.addRow(new Object[]{"Tax Payable", 0.0});
        tableModel.addRow(new Object[]{"Rebate (Savings)", 0.0});
        tableModel.addRow(new Object[]{"Final Tax", 0.0});

        resultTable = new JTable(tableModel);
        resultTable.setBackground(new Color(35, 35, 35));
        resultTable.setForeground(Color.WHITE);
        resultTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        resultTable.setRowHeight(28);
        resultTable.setGridColor(new Color(0, 200, 200));

        resultTable.getTableHeader().setBackground(new Color(0, 200, 255));
        resultTable.getTableHeader().setForeground(Color.BLACK);
        resultTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        resultTable.setSelectionBackground(new Color(50, 50, 50));
        resultTable.setSelectionForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(resultTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0, 200, 200), 1));
        add(scrollPane, BorderLayout.CENTER);

        // ---------- Buttons ----------
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(new Color(25, 25, 25));

        JButton calculateBtn = new JButton("Calculate Tax");
        styleMainButton(calculateBtn, new Color(139, 0, 139), new Color(255, 255, 255));
        calculateBtn.addActionListener(this::calculateTax);

        JButton pdfBtn = new JButton("📄 Save as PDF");
        styleMainButton(pdfBtn, new Color(0, 120, 200), new Color(255, 255, 255));
        pdfBtn.addActionListener(e -> savePdf());

        JButton closeBtn2 = new JButton("Close");
        styleMainButton(closeBtn2, new Color(255, 100, 180), new Color(255, 255, 255));
        closeBtn2.addActionListener(e -> dispose());

        buttonPanel.add(calculateBtn);
        buttonPanel.add(pdfBtn);
        buttonPanel.add(closeBtn2);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void calculateTax(ActionEvent e) {
        try {
            double monthlyIncome = Double.parseDouble(incomeField.getText());
            if (monthlyIncome < 0) {
                JOptionPane.showMessageDialog(this, "Income cannot be negative.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double annualIncome = monthlyIncome * 12.0;
            boolean hasShanchaypatra = shanchayCheckBox.isSelected();

            double taxRate = 0.10;
            double taxPayable = annualIncome * taxRate;
            double rebate = 0;

            if (hasShanchaypatra) {
                try {
                    String savingsText = savingsAmountField.getText().trim();
                    if (savingsText.isEmpty()) {
                        JOptionPane.showMessageDialog(this, "Please enter your savings certificate amount.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    savingsAmount = Double.parseDouble(savingsText);
                    if (savingsAmount <= 300000) {
                        rebate = savingsAmount * 0.10;
                    } else {
                        rebate = 30000;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Invalid savings amount.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            double finalTax = taxPayable - rebate;

            // Update table
            tableModel.setValueAt(annualIncome, 0, 1);
            tableModel.setValueAt(annualIncome, 1, 1);
            tableModel.setValueAt("10%", 2, 1);
            tableModel.setValueAt(taxPayable, 3, 1);
            tableModel.setValueAt("Rebate (Savings: ৳" + savingsAmount + ")", 4, 0);
            tableModel.setValueAt(rebate, 4, 1);
            tableModel.setValueAt(finalTax, 5, 1);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid income number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void savePdf() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Please calculate tax first.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Document doc = new Document();
            File file = new File("TaxReport.pdf");
            PdfWriter.getInstance(doc, new FileOutputStream(file));
            doc.open();

            // Logo
            try {
                com.lowagie.text.Image logo = null;
                File logoFile = new File("my_logo.png"); 
                if (logoFile.exists()) {
                    logo = com.lowagie.text.Image.getInstance(logoFile.getAbsolutePath());
                    logo.scaleToFit(100, 100);
                    logo.setAlignment(com.lowagie.text.Image.ALIGN_CENTER);
                    doc.add(logo);
                }
            } catch (Exception e) {
                System.out.println("Logo not loaded: " + e.getMessage());
            }

            doc.add(new Paragraph("\n"));

            // Title
            com.lowagie.text.Font titleFont = new com.lowagie.text.Font(
                    com.lowagie.text.Font.HELVETICA, 18, com.lowagie.text.Font.BOLD
            );
            Paragraph title = new Paragraph("💰 Tax Report (Government of Bangladesh)", titleFont);
            title.setAlignment(Paragraph.ALIGN_CENTER);
            doc.add(title);
            doc.add(new Paragraph("\n"));

            // Bangladesh Flag
            BangladeshFlag flagPanel = new BangladeshFlag();
            flagPanel.setSize(200, 120);

            java.awt.image.BufferedImage flagImage = new java.awt.image.BufferedImage(
                    flagPanel.getWidth(),
                    flagPanel.getHeight(),
                    java.awt.image.BufferedImage.TYPE_INT_ARGB
            );
            Graphics2D g2d = flagImage.createGraphics();
            flagPanel.paint(g2d);
            g2d.dispose();

            com.lowagie.text.Image flag = com.lowagie.text.Image.getInstance(flagImage, null);
            flag.setAlignment(com.lowagie.text.Image.ALIGN_CENTER);
            doc.add(flag);

            doc.add(new Paragraph("\n"));

            // Tax Table
            PdfPTable pdfTable = new PdfPTable(2);
            pdfTable.setWidthPercentage(100);
            pdfTable.addCell("Description");
            pdfTable.addCell("Amount (৳)");

            for (int i = 0; i < tableModel.getRowCount(); i++) {
                pdfTable.addCell(tableModel.getValueAt(i, 0).toString());
                pdfTable.addCell(tableModel.getValueAt(i, 1).toString());
            }

            doc.add(pdfTable);
            doc.close();

            JOptionPane.showMessageDialog(this, "PDF saved successfully: " + file.getAbsolutePath());

            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(file);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving PDF: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ---------- Styling Helpers ----------
    private void styleField(JTextField field) {
        field.setForeground(Color.WHITE);
        field.setBackground(new Color(35, 35, 35));
        field.setBorder(BorderFactory.createLineBorder(new Color(0, 200, 200), 2, true));
    }

    private void styleRadio(JRadioButton btn) {
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(25, 25, 25));
        btn.setBorder(new LineBorder(new Color(0, 200, 200), 1, true));
    }

    private void styleMainButton(JButton btn, Color base, Color hover) {
        btn.setFocusPainted(false);
        btn.setBackground(base);
        btn.setForeground(Color.BLACK);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createLineBorder(new Color(0, 200, 200), 1, true));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(base);
            }
        });
    }
}