package com.mycompany.personalfinancetracker;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class MainFrame extends JFrame {
    private final FinanceManager manager;
    private JTable table;
    private DefaultTableModel tableModel;
    private Point initialClick;

    public MainFrame(FinanceManager manager) {
        this.manager = manager;
        initUI();
        refreshTable();
    }

    private void initUI() {
        setUndecorated(true); // remove OS title bar
        setSize(1200, 650);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // -------- Custom Cyan Title Bar --------
        JPanel titleBar = new JPanel(new BorderLayout());
        titleBar.setBackground(new Color(0, 180, 200));
        titleBar.setPreferredSize(new Dimension(getWidth(), 40));

        JLabel titleLabel = new JLabel("💵 TaxFusion Finance");
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 0));

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 6));
        controlPanel.setOpaque(false);
        JButton minBtn = createTitleButton("–", new Color(0,0,0));
        JButton maxBtn = createTitleButton("█", new Color(0, 0, 0));
        JButton closeBtn = createTitleButton("X", new Color(0, 0, 0));

        minBtn.addActionListener(e -> setState(JFrame.ICONIFIED));
        maxBtn.addActionListener(e -> {
            if (getExtendedState() == JFrame.MAXIMIZED_BOTH) {
                setExtendedState(JFrame.NORMAL);
            } else {
                setExtendedState(JFrame.MAXIMIZED_BOTH);
            }
        });
        closeBtn.addActionListener(e -> System.exit(0));

        controlPanel.add(minBtn);
        controlPanel.add(maxBtn);
        controlPanel.add(closeBtn);

        titleBar.add(titleLabel, BorderLayout.WEST);
        titleBar.add(controlPanel, BorderLayout.EAST);

        // Dragging functionality
        titleBar.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { initialClick = e.getPoint(); }
        });
        titleBar.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int thisX = getLocation().x;
                int thisY = getLocation().y;
                int xMoved = e.getX() - initialClick.x;
                int yMoved = e.getY() - initialClick.y;
                setLocation(thisX + xMoved, thisY + yMoved);
            }
        });

        applyDarkTheme();

        // -------- Buttons Panel (below title bar) --------
        JButton setIncomeBtn = createButton("Set Monthly Income");
        JButton addExpenseBtn = createButton("Add Expense");
        JButton monthlyReportBtn = createButton("View Monthly Summary Report");
        JButton dailyReportBtn = createButton("View Day-to-Day Detailed Report");
        JButton taxCalcBtn = createButton("💰 Tax Calculator");

        setIncomeBtn.addActionListener(e -> showSetIncomeDialog());
        addExpenseBtn.addActionListener(e -> showAddExpenseDialog());
        monthlyReportBtn.addActionListener(e -> showMonthlyFinalReport());
        dailyReportBtn.addActionListener(e -> showDayToDayReport());
        taxCalcBtn.addActionListener(e -> showTaxCalculator());

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        btnPanel.setOpaque(false);
        btnPanel.add(setIncomeBtn);
        btnPanel.add(addExpenseBtn);
        btnPanel.add(monthlyReportBtn);
        btnPanel.add(dailyReportBtn);
        btnPanel.add(taxCalcBtn);

        // -------- Combine Title Bar + Button Panel --------
        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.add(titleBar, BorderLayout.NORTH);
        topContainer.add(btnPanel, BorderLayout.SOUTH);
        add(topContainer, BorderLayout.NORTH);

        // -------- Table --------
        String[] cols = {"Date", "Income", "Sector", "Expense", "Savings", "Loan"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(new LineBorder(new Color(0, 200, 200), 2, true));
        scrollPane.setBackground(new Color(30, 30, 30));
        scrollPane.getViewport().setBackground(new Color(30, 30, 30));
        add(scrollPane, BorderLayout.CENTER);

        // -------- Pie Chart --------
        ExpensePieChartPanel chartPanel = new ExpensePieChartPanel(manager);
        chartPanel.setBorder(new LineBorder(new Color(0, 200, 200), 2, true));
        add(chartPanel, BorderLayout.EAST);
    }

    // ---------- Theme ----------
    private void applyDarkTheme() {
        Color bg = new Color(30, 30, 30);
        Color fg = Color.WHITE;
        getContentPane().setBackground(bg);
        UIManager.put("Panel.background", bg);
        UIManager.put("OptionPane.background", bg);
        UIManager.put("OptionPane.messageForeground", fg);
        UIManager.put("Button.background", new Color(60, 63, 65));
        UIManager.put("Button.foreground", fg);
        UIManager.put("Label.foreground", fg);
        UIManager.put("Table.background", new Color(45, 45, 45));
        UIManager.put("Table.foreground", fg);
        UIManager.put("Table.gridColor", new Color(80, 80, 80));
        UIManager.put("Table.selectionBackground", new Color(70, 70, 150));
        UIManager.put("Table.selectionForeground", Color.WHITE);
        UIManager.put("TextField.background", new Color(40, 40, 40));
        UIManager.put("TextField.foreground", fg);
        UIManager.put("TextArea.background", new Color(45, 45, 45));
        UIManager.put("TextArea.foreground", fg);
        UIManager.put("ScrollPane.background", bg);
        UIManager.put("Viewport.background", bg);
    }

    // ---------- Buttons ----------
    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(new Color(60, 63, 65));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btn.setPreferredSize(new Dimension(200, 40));
        btn.setBorder(new LineBorder(new Color(0, 200, 200), 2, true));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JButton createTitleButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setForeground(Color.BLACK);
        btn.setBackground(new Color(0, 180, 200));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        btn.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(new Color(0, 140, 160)); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(new Color(0, 180, 200)); }
        });
        return btn;
    }

    // ---------- Table styling ----------
    private void styleTable(JTable t) {
        t.setRowHeight(28);
        t.getTableHeader().setBackground(new Color(45, 45, 45));
        t.getTableHeader().setForeground(Color.WHITE);
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        t.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        t.setBackground(new Color(45, 45, 45));
        t.setForeground(Color.WHITE);
        t.setGridColor(new Color(80, 80, 80));
        t.setSelectionBackground(new Color(70, 70, 150));
        t.setSelectionForeground(Color.WHITE);
    }

    // ---------- Data refresh with CORRECT logic ----------
    private void refreshTable() {
        tableModel.setRowCount(0);
        String my = manager.getCurrentMonthYear();
        if (my.isEmpty()) return;

        double income = manager.getMonthlyIncome(my);
        List<Transaction> txns = manager.getTransactionsCurrentMonth();
        List<String> dates = manager.getAllDatesInMonth();

        int idx = 0;
        double cumulativeExpenses = 0; // Track total expenses
        double cumulativeLoan = 0;     // Track total loans

        for (String d : dates) {
            String sector = "";
            double expenseAmount = 0;
            double loanAmount = 0;
            
            // Check if we have a transaction for this date
            if (idx < txns.size() && txns.get(idx).getDate().equals(d)) {
                Transaction t = txns.get(idx++);
                sector = t.getExpenseSector();
                expenseAmount = t.getExpenseAmount();
                loanAmount = t.getLoanAmount();
            }

            // Add to cumulative totals
            cumulativeExpenses += expenseAmount;
            cumulativeLoan += loanAmount;
            
            // Savings = Income - Total Expenses (but can't be negative)
            double savings = Math.max(0, income - cumulativeExpenses);

            tableModel.addRow(new Object[]{
                    d,
                    String.format("৳ %.2f", income),
                    sector,
                    String.format("৳ %.2f", expenseAmount),
                    String.format("৳ %.2f", savings),
                    String.format("৳ %.2f", cumulativeLoan)
            });
        }

        for (Component c : getContentPane().getComponents())
            if (c instanceof ExpensePieChartPanel) c.repaint();
    }

    // ---------- Dialogs ----------
    private void showSetIncomeDialog() {
        new SetMonthlyIncomeDialog(this, manager, v -> refreshTable()).setVisible(true);
    }

    private void showAddExpenseDialog() {
        new AddExpenseDialog(this, manager, v -> refreshTable()).setVisible(true);
    }

    private void showMonthlyFinalReport() {
        new MonthlyReportDialog(this, manager).setVisible(true);
    }

    private void showDayToDayReport() {
        new DayToDayReportDialog(this, manager).setVisible(true);
    }

    private void showTaxCalculator() {
        new TaxDialog(this, manager).setVisible(true);
    }
}