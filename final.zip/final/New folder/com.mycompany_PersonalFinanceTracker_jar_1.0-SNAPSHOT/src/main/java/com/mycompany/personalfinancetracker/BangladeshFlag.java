package com.mycompany.personalfinancetracker;
import javax.swing.*;
import java.awt.*;

class BangladeshFlag extends JPanel {

    public BangladeshFlag() {
        setPreferredSize(new Dimension(40, 24)); // UI-friendly size
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();

        // Smooth edges
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Green background
        g2.setColor(new Color(0, 106, 78));
        g2.fillRect(0, 0, getWidth(), getHeight());

        // Smaller red circle
        int margin = 6; // fixed margin around circle
        int diameter = Math.min(getWidth(), getHeight()) - 2 * margin;

        int circleX = (getWidth() - diameter) / 2 - 1; // slight left shift
        int circleY = (getHeight() - diameter) / 2;

        g2.setColor(new Color(244, 42, 65));
        g2.fillOval(circleX, circleY, diameter, diameter);

        g2.dispose();
    }
}