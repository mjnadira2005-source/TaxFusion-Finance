


package com.mycompany.personalfinancetracker;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.FileOutputStream;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Image;
import com.lowagie.text.pdf.PdfWriter;
import java.io.File;
import java.awt.Desktop;
import java.io.IOException;
import javax.swing.border.LineBorder;


import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

/**
 * Dialog that displays a clean, dark-themed monthly report including income, expenses, loans, savings,
 * and a pie chart of expenses. Supports exporting the report to PDF using OpenPDF + JFreeChart.
 */
public class MonthlyReportDialog extends JDialog {
    private final FinanceManager manager;

    public MonthlyReportDialog(JFrame parent, FinanceManager manager) {
        super(parent, "📊 Monthly Report", true);
        this.manager = manager;
        setUndecorated(true);
        initUI();
    }

    private void initUI() {
        setLayout(new BorderLayout(15, 15));
        setSize(700, 520); // wider to fit chart
        setLocationRelativeTo(getParent());
        setResizable(false);
          getRootPane().setBorder(new LineBorder(new Color(0, 200, 200), 3, true));

        JPanel titleBar = new JPanel(new BorderLayout());
titleBar.setBackground(Color.CYAN);
titleBar.setPreferredSize(new Dimension(getWidth(), 35));
JLabel titleLabel = new JLabel("Monthly Report Analysis", SwingConstants.CENTER);
titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
titleLabel.setForeground(Color.BLACK);
titleBar.add(titleLabel, BorderLayout.CENTER);

JButton closeBtn1 = new JButton("X");
JButton minimizeBtn = new JButton("—");
// style them with your styleButton method or a lighter variant
closeBtn1.addActionListener(e -> dispose());
//minimizeBtn.addActionListener(e -> setState(Frame.ICONIFIED));
minimizeBtn.addActionListener(e -> toBack());

JPanel btnPanel1 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 2));
btnPanel1.setOpaque(false);
btnPanel1.add(minimizeBtn);
btnPanel1.add(closeBtn1);

titleBar.add(btnPanel1, BorderLayout.EAST);
add(titleBar, BorderLayout.NORTH);
        

        applyDarkTheme();

        String month = manager.getCurrentMonth();
        if (month.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this, "Please set monthly income first.", "No Data", JOptionPane.WARNING_MESSAGE
            );
            dispose();
            return;
        }

        double income = manager.getMonthlyIncome(month);
        double totalExpenses = manager.getTotalExpenses(month);
        double totalLoans = manager.getTotalLoans(month);
        double finalSavings = manager.getFinalSavings(month);

        // === Summary Panel ===
        JPanel summaryPanel = new JPanel(new GridBagLayout());
        summaryPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridx = 0;
        gbc.gridy = 0;

        JLabel title = new JLabel("Monthly Summary — " + month);
        title.setFont(new Font("Segoe UI Semibold", Font.BOLD, 22));
        title.setForeground(new Color(255, 215, 0)); // Gold
        gbc.gridwidth = 2;
        summaryPanel.add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++;

        addRow(summaryPanel, gbc, "Income:", income, new Color(0, 200, 255));
        addRow(summaryPanel, gbc, "Total Expenses:", totalExpenses, new Color(255, 99, 99));
        addRow(summaryPanel, gbc, "Total Loans:", totalLoans, new Color(139,0,0));
        addRow(summaryPanel, gbc, "Final Savings:", finalSavings > 0 ? finalSavings : 0,
                finalSavings >= 0 ? new Color(100, 255, 150) : Color.RED);

        // === Pie Chart Panel (Swing display) ===
        ExpensePieChartPanel pieChartPanel = new ExpensePieChartPanel(manager);

        JPanel centerPanel = new JPanel(new GridLayout(1, 2));
        centerPanel.setOpaque(false);
        centerPanel.add(summaryPanel);
        centerPanel.add(pieChartPanel);

        // === Button Panel ===
        JPanel btnPanel = new JPanel();
        btnPanel.setOpaque(false);

        JButton pdfBtn = createStyledButton("Save as PDF");
        pdfBtn.addActionListener(e -> exportToPDF(month, income, totalExpenses, totalLoans, finalSavings));
        btnPanel.add(pdfBtn);

        JButton closeBtn = createStyledButton("Close");
        closeBtn.addActionListener(e -> dispose());
        btnPanel.add(closeBtn);

        add(centerPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);
    }

    /** Export report to PDF with pie chart using OpenPDF + JFreeChart */
   private void exportToPDF(String month, double income, double expenses, double loans, double savings) {
    JFileChooser chooser = new JFileChooser();
    chooser.setDialogTitle("Save Report as PDF");
    if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
        try {
            // === Apply your business rule again ===
            double adjustedLoan;
            double adjustedSavings;

            if (expenses > income) {
                adjustedLoan = expenses - income; // overspending becomes loan
                adjustedSavings = 0;              // savings forced to zero
            } else {
                adjustedLoan = loans;
                adjustedSavings = income - expenses - loans;
                if (adjustedSavings < 0) adjustedSavings = 0; // safety guard
            }

            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(chooser.getSelectedFile() + ".pdf"));
            document.open();
com.lowagie.text.Font titleFont=new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA,18,com.lowagie.text.Font.BOLD);
           Paragraph title=new Paragraph("Monthly Report for "+month,titleFont);
           title.setAlignment(Paragraph.ALIGN_CENTER);
           document.add(title);
           document.add(new Paragraph("\n"));
            document.add(new Paragraph("Income: ৳ " + String.format("%.2f", income)));
            document.add(new Paragraph("Total Expenses: ৳ " + String.format("%.2f", expenses)));
            document.add(new Paragraph("Total Loans: ৳ " + String.format("%.2f", adjustedLoan)));
            document.add(new Paragraph("Final Savings: ৳ " + String.format("%.2f", adjustedSavings)));
            document.add(new Paragraph("\nExpense Breakdown:"));

            // === Pie chart using JFreeChart ===
            DefaultPieDataset dataset = new DefaultPieDataset();
            dataset.setValue("Expenses", expenses);
            dataset.setValue("Loans", adjustedLoan);
            dataset.setValue("Savings", adjustedSavings);

            JFreeChart chart = ChartFactory.createPieChart(
                    "Expense Breakdown", dataset, true, true, false);

            BufferedImage chartImage = chart.createBufferedImage(400, 300);
            Image pdfImage = Image.getInstance(chartImage, null);
            document.add(pdfImage);

            document.close();
            JOptionPane.showMessageDialog(this, "PDF saved successfully!");

            // Auto-open PDF
            try {
                Desktop.getDesktop().open(new File(chooser.getSelectedFile() + ".pdf"));
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                    "Could not open PDF automatically: " + ex.getMessage(),
                    "Open Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving PDF: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}



        //Desktop.getDesktop().open(new File(chooser.getSelectedFile() + ".pdf"));


    

    /** Adds a colored row of (label, value) to the report panel. */
    private void addRow(JPanel panel, GridBagConstraints gbc, String label, double value, Color color) {
        gbc.gridx = 0;
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lbl.setForeground(Color.WHITE);
        panel.add(lbl, gbc);

        gbc.gridx = 1;
        JLabel valLabel = new JLabel(String.format("৳ %.2f", value));
        valLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        valLabel.setForeground(color);
        panel.add(valLabel, gbc);

        gbc.gridy++;
    }

    /** Applies a consistent dark theme. */
    private void applyDarkTheme() {
        Color bg = new Color(28, 28, 28);
        Color fg = new Color(230, 230, 230);
        getContentPane().setBackground(bg);

        UIManager.put("OptionPane.background", bg);
        UIManager.put("OptionPane.messageForeground", fg);
        UIManager.put("Button.background", new Color(50, 50, 50));
        UIManager.put("Button.foreground", fg);
    }

    /** Creates a styled button for dark theme. */
    private JButton createStyledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(new Color(60, 63, 65));
        btn.setForeground(Color.WHITE);
            btn.setBorder(BorderFactory.createLineBorder(new Color(0,200,200),2));
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btn.setPreferredSize(new Dimension(120, 36));
        return btn;
    }
}
