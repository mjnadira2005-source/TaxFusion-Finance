package com.mycompany.personalfinancetracker;

public class TaxCalculate {

    /** Calculates annual tax amount */
    public static double calculateAnnualTax(double annualIncome, boolean isFemale, boolean hasShanchaypatra) {
        double exemptionLimit = isFemale ? 400000 : 350000;  // Tax-free threshold
        double taxable = Math.max(0, annualIncome - exemptionLimit);
        double tax = 0.0;

        if (taxable > 0) {
            double remaining = taxable;

            double slab = Math.min(100000, remaining);
            tax += slab * 0.05;
            remaining -= slab;

            if (remaining > 0) {
                slab = Math.min(300000, remaining);
                tax += slab * 0.10;
                remaining -= slab;
            }

            if (remaining > 0) {
                slab = Math.min(400000, remaining);
                tax += slab * 0.15;
                remaining -= slab;
            }

            if (remaining > 0) {
                slab = Math.min(500000, remaining);
                tax += slab * 0.20;
                remaining -= slab;
            }

            if (remaining > 0) {
                tax += remaining * 0.25;
            }
        }

        if (hasShanchaypatra) tax *= 0.90;

        return Math.max(tax, 0);
    }

    /** Calculates monthly tax */
    public static double calculateMonthlyTax(double annualIncome, boolean isFemale, boolean hasShanchaypatra) {
        return calculateAnnualTax(annualIncome, isFemale, hasShanchaypatra) / 12.0;
    }

    /** Returns formatted tax summary for UI */
    public static String getTaxSummary(double annualIncome, boolean isFemale, boolean hasShanchaypatra) {
        double annualTax = calculateAnnualTax(annualIncome, isFemale, hasShanchaypatra);
        double monthlyTax = annualTax / 12.0;

        String category = isFemale ? "Female Taxpayer" : "Male";
        String shanchayText = hasShanchaypatra ? "✅ Has Saving Certificate (10% rebate applied)" : "❌ No Saving Certificate";

        return String.format(
                "🇧🇩 TAX CALCULATION SUMMARY\n" +
                "-----------------------------\n" +
                "Category: %s\n" +
                "Annual Income: ৳ %.2f\n" +
                "Annual Tax Payable: ৳ %.2f\n" +
                "Monthly Tax Deduction: ৳ %.2f\n" +
                "%s\n",
                category, annualIncome, annualTax, monthlyTax, shanchayText
        );
    }

    /** Returns detailed step-by-step tax breakdown */
    public static String getTaxBreakdown(double annualIncome, boolean isFemale, boolean hasShanchaypatra) {
        double exemptionLimit = isFemale ? 400000 : 350000;
        double taxable = Math.max(0, annualIncome - exemptionLimit);
        double tax = 0.0;
        double remaining = taxable;

        StringBuilder breakdown = new StringBuilder();
        breakdown.append("💡 Tax Calculation Steps:\n");
        breakdown.append(String.format("Exemption Limit: ৳ %.2f\n", exemptionLimit));
        breakdown.append(String.format("Taxable Income: ৳ %.2f\n\n", taxable));

        if (remaining > 0) {
            double slab;

            slab = Math.min(100000, remaining);
            tax += slab * 0.05;
            breakdown.append(String.format("1️⃣ First ৳ %.2f @ 5%% → Tax: ৳ %.2f\n", slab, slab * 0.05));
            remaining -= slab;

            if (remaining > 0) {
                slab = Math.min(300000, remaining);
                tax += slab * 0.10;
                breakdown.append(String.format("2️⃣ Next ৳ %.2f @ 10%% → Tax: ৳ %.2f\n", slab, slab * 0.10));
                remaining -= slab;
            }

            if (remaining > 0) {
                slab = Math.min(400000, remaining);
                tax += slab * 0.15;
                breakdown.append(String.format("3️⃣ Next ৳ %.2f @ 15%% → Tax: ৳ %.2f\n", slab, slab * 0.15));
                remaining -= slab;
            }

            if (remaining > 0) {
                slab = Math.min(500000, remaining);
                tax += slab * 0.20;
                breakdown.append(String.format("4️⃣ Next ৳ %.2f @ 20%% → Tax: ৳ %.2f\n", slab, slab * 0.20));
                remaining -= slab;
            }

            if (remaining > 0) {
                tax += remaining * 0.25;
                breakdown.append(String.format("5️⃣ Remaining ৳ %.2f @ 25%% → Tax: ৳ %.2f\n", remaining, remaining * 0.25));
            }
        }

        if (hasShanchaypatra) {
            breakdown.append(String.format("\n💰 Saving Certificate rebate applied (10%% off) → Tax before rebate: ৳ %.2f\n", tax));
            tax *= 0.90;
            breakdown.append(String.format("\n💰 Tax after rebate: ৳ %.2f\n", tax));
        }

        breakdown.append(String.format("\n📝 Total Annual Tax: ৳ %.2f\n", tax));
        breakdown.append(String.format("\n🗓 Monthly Tax Deduction: ৳ %.2f\n", tax / 12.0));

        return breakdown.toString();
    }
}
