//package com.mycompany.personalfinancetracker;
//
//import java.time.Month;
//import java.time.Year;
//import java.time.format.TextStyle;
//import java.util.*;
//import java.util.stream.Collectors;
//
//public class FinanceManager {
//    private final Map<String, Double> monthlyIncomes = new HashMap<>();
//    private final List<Transaction> transactions = new ArrayList<>();
//    private String currentMonthYear = ""; // e.g., "11/2025"
//
//    public void setMonthlyIncome(String monthYear, double income) {
//        monthlyIncomes.put(monthYear, income);
//        currentMonthYear = monthYear;
//    }
//
//    public double getMonthlyIncome(String monthYear) {
//        return monthlyIncomes.getOrDefault(monthYear, 0.0);
//    }
//
//    
//       
//    
//
//    public String getFullMonthName(String monthYear) {
//        if (monthYear.isEmpty()) return "";
//        String[] parts = monthYear.split("/");
//        int month = Integer.parseInt(parts[0]);
//        int year = Integer.parseInt(parts[1]);
//        return Month.of(month).getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + year;
//    }
//
//    public void addTransaction(Transaction t) {
//        transactions.add(t);
//    }
//
//    private List<Transaction> filterByMonthYear(String monthYear) {
//        return transactions.stream()
//                .filter(t -> t.getMonthYear().equals(monthYear))
//                .sorted(Comparator.comparing(Transaction::getDate))
//                .collect(Collectors.toList());
//    }
//
//    public double getTotalExpenses(String monthYear) {
//        return filterByMonthYear(monthYear).stream()
//                .mapToDouble(Transaction::getExpenseAmount)
//                .sum();
//    }
//
//    public double getTotalLoans(String monthYear) {
//        return filterByMonthYear(monthYear).stream()
//                .mapToDouble(Transaction::getLoanAmount)
//                .sum();
//    }
//
//    public double getFinalSavings(String monthYear) {
//        double income = getMonthlyIncome(monthYear);
//        double expenses = getTotalExpenses(monthYear);
//        double loans = getTotalLoans(monthYear);
//        double savings = (income - expenses )>=0?(income-expenses):0;
//        return (loans > 0) ? 0.0 : savings; // Cap at 0 if loans >0
//    }
//
//    public List<Transaction> getTransactionsCurrentMonth() {
//        if (currentMonthYear.isEmpty()) return Collections.emptyList();
//        return filterByMonthYear(currentMonthYear);
//    }
//
//    public Map<String, Double> getExpensesBySector() {
//        if (currentMonthYear.isEmpty()) return Collections.emptyMap();
//        return filterByMonthYear(currentMonthYear).stream()
//                .filter(t -> t.getExpenseAmount() > 0)
//                .collect(Collectors.groupingBy(
//                        Transaction::getExpenseSector,
//                        Collectors.summingDouble(Transaction::getExpenseAmount)
//                ));
//    }
//
//    public List<String> getAllDatesInMonth() {
//        List<Transaction> txns = getTransactionsCurrentMonth();
//        Set<String> dates = new TreeSet<>();
//        for (Transaction t : txns) {
//            dates.add(t.getDate());
//        }
//        if (!txns.isEmpty()) {
//            String first = txns.get(0).getDate();
//            int year = Integer.parseInt(first.substring(6));
//            int month = Integer.parseInt(first.substring(3, 5));
//            Calendar cal = Calendar.getInstance();
//            cal.set(year, month - 1, 1);
//            int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
//            for (int d = 1; d <= maxDay; d++) {
//                dates.add(String.format("%02d/%02d/%d", d, month, year));
//            }
//        }
//        return new ArrayList<>(dates);
//    }
//
//    String getCurrentMonth() {
//         return currentMonthYear;
//    }
//
//    String getCurrentMonthYear() {
//        return currentMonthYear; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
//}
package com.mycompany.personalfinancetracker;

import java.time.Month;
import java.time.Year;
import java.time.format.TextStyle;
import java.util.*;
import java.util.stream.Collectors;

public class FinanceManager {
    private final Map<String, Double> monthlyIncomes = new HashMap<>();
    private final List<Transaction> transactions = new ArrayList<>();
    private String currentMonthYear = ""; // e.g., "11/2025"

    public void setMonthlyIncome(String monthYear, double income) {
        monthlyIncomes.put(monthYear, income);
        currentMonthYear = monthYear;
    }

    public double getMonthlyIncome(String monthYear) {
        return monthlyIncomes.getOrDefault(monthYear, 0.0);
    }

    public String getFullMonthName(String monthYear) {
        if (monthYear.isEmpty()) return "";
        String[] parts = monthYear.split("/");
        int month = Integer.parseInt(parts[0]);
        int year = Integer.parseInt(parts[1]);
        return Month.of(month).getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + year;
    }

    public void addTransaction(Transaction t) {
        transactions.add(t);
    }

    private List<Transaction> filterByMonthYear(String monthYear) {
        return transactions.stream()
                .filter(t -> t.getMonthYear().equals(monthYear))
                .sorted(Comparator.comparing(Transaction::getDate))
                .collect(Collectors.toList());
    }

    public double getTotalExpenses(String monthYear) {
        return filterByMonthYear(monthYear).stream()
                .mapToDouble(Transaction::getExpenseAmount)
                .sum();
    }

    public double getTotalLoans(String monthYear) {
        return filterByMonthYear(monthYear).stream()
                .mapToDouble(Transaction::getLoanAmount)
                .sum();
    }

    /**
     * Calculates final savings based on cumulative logic:
     * Start with income, subtract expenses day by day.
     * If balance goes negative, that's a loan.
     */
    public double getFinalSavings(String monthYear) {
        double income = getMonthlyIncome(monthYear);
        List<Transaction> txns = filterByMonthYear(monthYear);
        
        double balance = income;
        
        for (Transaction t : txns) {
            balance -= t.getExpenseAmount();
        }
        
        // If balance is negative, savings = 0 (we're in debt)
        // If balance is positive, that's our savings
        return Math.max(0, balance);
    }

    public List<Transaction> getTransactionsCurrentMonth() {
        if (currentMonthYear.isEmpty()) return Collections.emptyList();
        return filterByMonthYear(currentMonthYear);
    }

    public Map<String, Double> getExpensesBySector() {
        if (currentMonthYear.isEmpty()) return Collections.emptyMap();
        return filterByMonthYear(currentMonthYear).stream()
                .filter(t -> t.getExpenseAmount() > 0)
                .collect(Collectors.groupingBy(
                        Transaction::getExpenseSector,
                        Collectors.summingDouble(Transaction::getExpenseAmount)
                ));
    }

    public List<String> getAllDatesInMonth() {
        List<Transaction> txns = getTransactionsCurrentMonth();
        Set<String> dates = new TreeSet<>();
        for (Transaction t : txns) {
            dates.add(t.getDate());
        }
        if (!txns.isEmpty()) {
            String first = txns.get(0).getDate();
            int year = Integer.parseInt(first.substring(6));
            int month = Integer.parseInt(first.substring(3, 5));
            Calendar cal = Calendar.getInstance();
            cal.set(year, month - 1, 1);
            int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            for (int d = 1; d <= maxDay; d++) {
                dates.add(String.format("%02d/%02d/%d", d, month, year));
            }
        }
        return new ArrayList<>(dates);
    }

    String getCurrentMonth() {
         return currentMonthYear;
    }

    String getCurrentMonthYear() {
        return currentMonthYear;
    }
}