package com.mycompany.personalfinancetracker;

import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;
import javax.swing.border.LineBorder;

public class SetMonthlyIncomeDialog extends JDialog {
    private final FinanceManager manager;
    private final Consumer<Void> refreshCallback;
    private JComboBox<String> monthCombo;
    private JTextField yearField;
    private JTextField incomeField;

    public SetMonthlyIncomeDialog(JFrame parent, FinanceManager manager, Consumer<Void> refreshCallback) {
        super(parent, true);
        this.manager = manager;
        this.refreshCallback = refreshCallback;
        setUndecorated(true); // remove native title bar
        initUI();
    }

    private void initUI() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(28, 28, 28));
               getRootPane().setBorder(new LineBorder(new Color(0, 200, 200), 3, true));

        // ----- Custom Cyan Title Bar -----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.CYAN);
        header.setBorder(BorderFactory.createLineBorder(new Color(0, 180, 255), 2));

        JLabel title = new JLabel("📅 Set Monthly Income");
        title.setForeground(Color.BLACK);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton closeBtn = new JButton("X");
        styleButton(closeBtn);
        closeBtn.setBackground(Color.CYAN);
        closeBtn.setForeground(Color.BLACK);
        closeBtn.setPreferredSize(new Dimension(50, 30));
        closeBtn.addActionListener(e -> dispose());

        header.add(title, BorderLayout.WEST);
        header.add(closeBtn, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // ----- Main Form -----
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(new Color(28, 28, 28));
        form.setBorder(BorderFactory.createLineBorder(new Color(0, 180, 255), 2)); // cyan border

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel monthLabel = new JLabel("Month:");
        styleLabel(monthLabel);

        JLabel yearLabel = new JLabel("Year:");
        styleLabel(yearLabel);

        JLabel incomeLabel = new JLabel("Monthly Income:");
        styleLabel(incomeLabel);

        // Month dropdown
        String[] months = {
                "01 - January", "02 - February", "03 - March", "04 - April",
                "05 - May", "06 - June", "07 - July", "08 - August",
                "09 - September", "10 - October", "11 - November", "12 - December"
        };
        monthCombo = new JComboBox<>(months);
        styleCombo(monthCombo);

        // Year field
        yearField = new JTextField(6);
        styleField(yearField);

        // Income field
        incomeField = new JTextField(10);
        styleField(incomeField);

        // Save button
        JButton saveButton = new JButton("💾 Save");
        styleButton(saveButton);
        saveButton.addActionListener(e -> onSave());

        gbc.gridx = 0; gbc.gridy = 0;
        form.add(monthLabel, gbc);
        gbc.gridx = 1;
        form.add(monthCombo, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        form.add(yearLabel, gbc);
        gbc.gridx = 1;
        form.add(yearField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        form.add(incomeLabel, gbc);
        gbc.gridx = 1;
        form.add(incomeField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        form.add(saveButton, gbc);

        add(form, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(getParent());
    }

    private void onSave() {
        try {
            String month = (String) monthCombo.getSelectedItem();
            String year = yearField.getText().trim();
            double income = Double.parseDouble(incomeField.getText().trim());

            if (year.isEmpty() || income < 0) {
                throw new IllegalArgumentException();
            }

            // Format month/year as "MM/YYYY"
            String monthYear = month.substring(0, 2) + "/" + year;

            manager.setMonthlyIncome(monthYear, income);
            if (refreshCallback != null) refreshCallback.accept(null);
            JOptionPane.showMessageDialog(this, "✅ Monthly income set successfully!");
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Invalid input. Please enter a valid year and positive income.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void styleLabel(JLabel lbl) {
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    }

    private void styleField(JTextField field) {
        field.setBackground(new Color(40, 40, 40));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    }

    private void styleCombo(JComboBox<String> combo) {
        combo.setBackground(new Color(40, 40, 40));
        combo.setForeground(Color.WHITE);
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    }

    private void styleButton(JButton btn) {
        btn.setFocusPainted(false);
        btn.setBackground(new Color(60, 63, 65));
        btn.setForeground(Color.WHITE);
        btn.setBorder(BorderFactory.createLineBorder(new Color(0,200,200),2));
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}
