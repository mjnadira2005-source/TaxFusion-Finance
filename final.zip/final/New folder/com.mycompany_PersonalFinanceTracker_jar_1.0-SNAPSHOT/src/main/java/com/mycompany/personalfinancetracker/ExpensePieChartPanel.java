package com.mycompany.personalfinancetracker;
import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A polished Swing panel that draws a pie chart of expenses by sector.
 * Fully dark-themed and responsive.
 */
public class ExpensePieChartPanel extends JPanel {
    private final FinanceManager manager;
    private final Color[] colors = {
            new Color(255, 99, 132),
            new Color(54, 162, 235),
            new Color(255, 206, 86),
            new Color(75, 192, 192),
            new Color(153, 102, 255),
            new Color(255, 159, 64)
    };

    public ExpensePieChartPanel(FinanceManager manager) {
        this.manager = manager;
        setPreferredSize(new Dimension(400, 350));
        setBackground(new Color(28, 28, 28));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawPieChart((Graphics2D) g);
    }

    private void drawPieChart(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        String month = manager.getCurrentMonth();
        if (month.isEmpty()) {
            drawMessage(g2, "Set monthly income first!");
            return;
        }

        List<Transaction> txns = manager.getTransactionsCurrentMonth();
        if (txns.isEmpty()) {
            drawMessage(g2, "No expenses yet for " + month);
            return;
        }

        Map<String, Double> sectorMap = new HashMap<>();
        for (Transaction t : txns) {
            sectorMap.put(t.getExpenseSector(),
                    sectorMap.getOrDefault(t.getExpenseSector(), 0.0) + t.getExpenseAmount());
        }

        double total = sectorMap.values().stream().mapToDouble(Double::doubleValue).sum();
        if (total <= 0) {
            drawMessage(g2, "No expenses recorded for " + month);
            return;
        }

        int diameter = Math.min(getWidth(), getHeight()) - 80;
        int x = (getWidth() - diameter) / 2;
        int y = 20;
        int startAngle = 0;
        int colorIndex = 0;

        // Draw pie slices
        for (Map.Entry<String, Double> entry : sectorMap.entrySet()) {
            int angle = (int) Math.round(360.0 * entry.getValue() / total);
            g2.setColor(colors[colorIndex % colors.length]);
            g2.fillArc(x, y, diameter, diameter, startAngle, angle);
            startAngle += angle;
            colorIndex++;
        }

        // Draw legend
        drawLegend(g2, sectorMap, x, y + diameter + 10);
    }

    private void drawLegend(Graphics2D g2, Map<String, Double> sectorMap, int startX, int startY) {
        g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
        int colorIndex = 0;
        int boxSize = 14;
        int padding = 8;

        for (Map.Entry<String, Double> entry : sectorMap.entrySet()) {
            g2.setColor(colors[colorIndex % colors.length]);
            g2.fillRect(startX, startY - boxSize, boxSize, boxSize);
            g2.setColor(Color.WHITE);
            g2.drawString(entry.getKey() + " : ৳" + String.format("%.2f", entry.getValue()), startX + boxSize + padding, startY);
            startY += boxSize + padding;
            colorIndex++;
        }
    }

    private void drawMessage(Graphics2D g2, String message) {
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Segoe UI", Font.BOLD, 14));
        FontMetrics fm = g2.getFontMetrics();
        int msgWidth = fm.stringWidth(message);
        int x = (getWidth() - msgWidth) / 2;
        int y = getHeight() / 2;
        g2.drawString(message, x, y);
    }
}
